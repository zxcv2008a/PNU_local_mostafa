package com.example.term;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.SearchView;

public class resturant_sub extends  AppCompatActivity {
    public SearchView search;
    public ListView resturants;
    public ImageButton filter_btn;

    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.coffeshops_choice);

        search = (SearchView)findViewById(R.id.search_bar);
        CharSequence query = search.getQuery();
        CharSequence queryHint = search.getQueryHint();
        boolean isIconfied=search.isIconfiedByDefault();
        resturants = (ListView)findViewById(R.id.resturant);
        filter_btn = (ImageButton)findViewById(R.id.filter_btn);

        filter_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(resturant_sub.this, restruant_filter_sub.class);
                startActivity(intent);
            }
        });
        resturants.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(resturant_sub.this, resturant_choice_sub.class);
                startActivity(intent);
            }
        });
       /* resturants.setOnItemClickListener(new AdapterView.OnItemClickListener(){
            public void onItemClick(AdapterView<?>adapter,View v, int position){
                ItemClicked item = adapter.getItemAtPosition(position);

                Intent intent = new Intent(resturant_sub.this,resturant_choice_sub.class);
                //based on item add info to intent
                startActivity(intent);
            }
        });*/
    }
}