package com.example.term;

import android.content.Intent;
import android.location.Location;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.SearchView;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Vector;

public class coffeshop_sub extends AppCompatActivity {
    public SearchView search;
    public ListView coffeshops;
    public ImageButton filter_btn;
    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.coffeshops_choice);

        //"lst" is result for Category
        Intent intent = getIntent();
        List buf = (List) intent.getSerializableExtra("Category");
        Vector lst = new Vector(buf);
        search = (SearchView)findViewById(R.id.search_bar);
        CharSequence query = search.getQuery();
        CharSequence queryHint = search.getQueryHint();
        boolean isIconfied=search.isIconfiedByDefault();
        coffeshops = (ListView)findViewById(R.id.coffeshops);
        filter_btn = (ImageButton)findViewById(R.id.filter_btn);

        ArrayList<String> name = new ArrayList<>();
        ArrayList star = new ArrayList<>();
        ArrayList LCS = new ArrayList<>();


        ArrayList latitude = new ArrayList<>();
        ArrayList longtitude = new ArrayList<>();
        double curlati= 35.012;
        double curlongti=-122.2302;

        for(int i=0;i<lst.size();i++)
        {
            Map<String,Object> shop = (Map<String, Object>) lst.elementAt(i);
            Iterator<String> keys = shop.keySet().iterator();
            while(keys.hasNext()){
                String key = keys.next();
                if(key.compareTo("name")==0) name.add(shop.get(key).toString());
                if(key.compareTo("star")==0) star.add(Integer.parseInt(shop.get(key).toString()));
                if(key.compareTo("latitude")==0) latitude.add(Double.parseDouble(shop.get(key).toString()));
                if(key.compareTo("longitude")==0) longtitude.add(Double.parseDouble(shop.get(key).toString()));
            }
        }

        ArrayAdapter adapter = new ArrayAdapter(coffeshop_sub.this,android.R.layout.simple_list_item_1, name);
        coffeshops.setAdapter(adapter);
        /*public ItemClicked getItem(int position){
    return items.get(position);
}*/
        filter_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(coffeshop_sub.this, cafe_filter_sub.class);
                startActivity(intent);
            }
        });
        coffeshops.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(coffeshop_sub.this, coffeshop_choice_sub.class);
                startActivity(intent);
            }
        });
        /*coffeshops.setOnItemClickListener(new AdapterView.OnItemClickListener(){
            public void onItemClick(AdapterView<?>adapter,View v, int position){
                ItemClicked item = adapter.getItemAtPosition(position);

                Intent intent = new Intent(coffeshop_sub.this,coffeshop_choice_sub.class);
                //based on item add info to intent
                startActivity(intent);
            }
        });*/
    }

    public void showlcs(String[] name , float []lcs,float []distances) {
        int leng=0;
        for(int i=0;i<name.length;i++){
            if(name[i]==null)break;
            leng++;
        }
        int lcscheck[] = new int[leng];//lcscheck가 1일경우 이미 순서가 정해진녀석(lcs값 큰녀석부터 정할것)
        int lcspri[] = new int[leng]; //lcs값이 높은 인덱스 순서대로 배열되어있음. first priority
        for (int i = 0; i < leng; i++)//lcspri[i]에 우선도 높은 index를 저장할
            {
            int maxpri=-1;
            for (int j = 0; j < leng; j++) { //maxpri에 우선도 높은 index값
                if (lcscheck[j] == 1) continue;
                if(maxpri==-1) maxpri = j;
                if (lcs[j] > lcs[maxpri]) maxpri = j;
            }
            lcspri[i] = maxpri;
            lcscheck[maxpri] = 1;
        }

        int discheck[] = new int[leng];
        int dispri[] = new int[leng];

        for(int i=0;i<leng;i++)// second priority(같은 lcs내에서 거리가 짧은순으로)
        {
            int start,last;
            int minpri=-1;
            start=i;
            last=i;
            int counter=0;
            while(lcspri[last]==lcspri[last+1])
            {
                last=last+1;
            }
            int attempt=last-start;
            while(attempt>0) {
                for (start = i; start < last + 1; start++) {
                    if (discheck[start] == 1) continue;
                    if(minpri==-1) minpri = start;
                    if (distances[start] < distances[minpri]) minpri = start;
                }
                dispri[counter++] = minpri;
                discheck[minpri] = 1;
                attempt=attempt-1;
            }
            start=last;
        }

        for(int i=0; i<leng;i++)
        {
            System.out.println("가게이름 : " + name[dispri[i]] +"\n");
        }
    }
    public double[] distances (String[] name, double []latitude, double []longitude, double curlati, double curlong)
     {
         int leng=0;
         for(int i=0;i<name.length;i++){
             if(name[i]==null)break;
             leng++;
         }
         Location curpos = new Location("curpos");
         curpos.setLatitude(curlati);
         curpos.setLongitude(curlong);
         double distances [] = new double[leng];
         Location locate [] = new Location[leng];
         for(int i=0; i<leng;i++) {
            locate[i].setLatitude(latitude[i]);
            locate[i].setLongitude(longitude[i]);
            distances[i]=(double)curpos.distanceTo(locate[i]);
            System.out.println("현위치서 거리 : " + distances[i] +"\n");
         }
         return distances;
     }

     public double[] getlcs(String search , String[] name ){  //가게들(name[])의 lcs값을 얻는다
         double[] LCS = new double[40];
         int leng=0;
         for(int i=0;i<name.length;i++){
             if(name[i]==null)break;
             leng++;
         }
         String A, B;
         for (int q = 0; q < leng; q++) {
             A = search;
             B = name[q];
             int Xblank = 0, Yblank = 0;

             int n = 0, m = 0;

             for (int i = 0; i<A.length(); i++)
             {
                 if (A.charAt(i)==' ') Xblank++;
                 n++;
             }

             for (int j = 0; j<B.length(); j++)
             {
                 if (B.charAt(j)==' ') Yblank++;
                 m++;
             }

             int matrix[][]= new int[m+1][n+1];

             for (int i = 0; i < m + 1; i++)
                 matrix[i][0] = 0;
             for (int i = 0; i < n + 1; i++)
                 matrix[0][i] = 0;

             for (int i = 1; i < m + 1; i++)
             {
                     for (int j = 1; j < n + 1; j++) {
                             if (B.charAt(i - 1) == A.charAt(j - 1))
                                 matrix[i][j] = matrix[i - 1][j - 1] + 1;
                             else {
                                 if (matrix[i][j - 1] >= matrix[i - 1][j])
                                     matrix[i][j] = matrix[i][j - 1];
                                 else if (matrix[i][j - 1] < matrix[i - 1][j])
                                     matrix[i][j] = matrix[i-1][j];
                             }
                     }
            }
             double o = 2 * matrix[m][n];
             double p = m + n - Xblank - Yblank;
             double s = o / p;
             LCS[q] = s;
            System.out.println("가게 : " + name[q] + " , LCS : " + s + "\n");
         }
          return LCS;
    }
   public void recoalgo(String[] name,float[] star){
       int leng=0;
       for(int i=0;i<name.length;i++){
           if(name[i]==null)break;
           leng++;
       }
        int pri[] = new int[leng];   //star값이 높은 index순서대로 저장
        int pricheck[] = new int[leng];  //index가 pri에 저장되었는지 확인
        for(int i=0;i<leng;i++)
        {
            int starpri=-1;
            for(int j=0;j<leng;j++) {
                if(pricheck[j]==1) continue;
                if(starpri==-1) starpri=j;
                if(star[starpri]<star[j]) starpri=j;
            }
            pricheck[starpri]=1;
            pri[i]=starpri;
        }
        for(int i=0; i<leng;i++)
        {
            System.out.println("가게이름 : " + name[pri[i]] +"\n");
        }
    }

}