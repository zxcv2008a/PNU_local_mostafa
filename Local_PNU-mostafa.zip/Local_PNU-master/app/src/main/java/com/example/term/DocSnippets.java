package com.example.term;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.auth.GetTokenResult;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.Query;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Vector;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

/**
 * Snippets for inclusion in documentation.
 */
@SuppressWarnings({"unused", "Convert2Lambda"})
public class DocSnippets extends AppCompatActivity implements DocSnippetsInterface {
    private static final String TAG = "DocSnippets";
    private static final ThreadPoolExecutor EXECUTOR = new ThreadPoolExecutor(2, 4,
            60, TimeUnit.SECONDS, new LinkedBlockingQueue<Runnable>());
    private FirebaseFirestore db;
    private Context ctx;
    private FirebaseAuth mAuth;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mAuth = FirebaseAuth.getInstance();
        this.db = FirebaseFirestore.getInstance();
        final Intent intent = getIntent();
        final String func = intent.getStringExtra("Function");
        if(func.compareTo("Category")==0) {
            ctx = getApplicationContext();
            getCategory(intent.getStringExtra("Category"), intent.getDoubleExtra("Latitude", 0.0), intent.getDoubleExtra("Longitude", 0.0));
        }
    }

    @Override
    public void addShop(String Kinds, String Shop_name, String Time, List Menu_name, List Menu_price, double latitude, double longitude) {
        // [START set_document]
        Map<String, Object> shop = new HashMap<>();
        Map<String, String> review = new HashMap<>();
        shop.put("name", Shop_name);
        shop.put("time", Time);
        shop.put("menu_name", Menu_name);
        shop.put("menu_price", Menu_price);
        shop.put("latitude", latitude);
        shop.put("longitude", longitude);
        shop.put("geohash", Geohasher.hash(new LatLng(latitude, longitude)));
        shop.put("star", 0);
        shop.put("review", review);
        db.collection(Kinds)
                .add(shop)
                .addOnSuccessListener(new OnSuccessListener<DocumentReference>() {
                    @Override
                    public void onSuccess(DocumentReference documentReference) {
                        Log.d(TAG, "DocumentSnapshot successfully written!");
                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Log.w(TAG, "Error writing document", e);
                    }
                });
    }

    @Override
    public void getShop(String Kinds, String Shop_name, final double latitude, final double longitude) {
        db.collection(Kinds).whereEqualTo("name", Shop_name).
                get().addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<QuerySnapshot> task) {
                        if (task.isSuccessful()) {
                        } else {
                            FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
                            if (user != null) {
                                user.getIdToken(true).addOnSuccessListener(new OnSuccessListener<GetTokenResult>() {
                                    @Override
                                    public void onSuccess(GetTokenResult getTokenResult) {
                                        String idToken = getTokenResult.getToken();
                                    }
                                });
                            }
                            Log.d(TAG, "get failed with ", task.getException());
                        }
                }
        });
    }

    @Override
    public void getCategory(String Kinds, final double latitude, final double longitude) {
        String under = new String( Geohasher.hash(new LatLng(latitude, longitude)).substring(0,6));
        String upper = under.substring(0,5) + (char)(under.charAt(5)+1);
        Query GPScol = db.collection(Kinds)
                .whereLessThan("geohash",upper)
                .whereGreaterThanOrEqualTo("geohash", under);
        GPScol.get()
                .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<QuerySnapshot> task) {
                        Vector<Map<String, Object>> lst = new Vector<Map<String, Object >>(), buf = new Vector<Map<String, Object >>();
                        if (task.isSuccessful()) {
                            String loc = Geohasher.hash(new LatLng(latitude, longitude));
                            for (QueryDocumentSnapshot document : task.getResult()) {
                                buf.add(document.getData());
                            }
                            for(int i=loc.length()-1; i>=0; i--){
                                for(int j=0; j<buf.size(); j++) {
                                    if (buf.elementAt(j).get("geohash").toString().substring(0, i).compareTo(loc.substring(0, i)) == 0) {
                                        if(lst.contains(buf.elementAt(j))) {
                                            continue;
                                        }
                                        lst.add(buf.elementAt(j));
                                    }
                                }
                            }
                            Intent intent = new Intent(DocSnippets.this, coffeshop_sub.class);
                            intent.putExtra("Category", lst);
                            System.out.println("printout: activity start");
                            startActivity(intent);
                            System.out.println("printout: activity end");
                            finish();

                        } else {
                            Log.w(TAG, "Error getting documents.", task.getException());
                        }
                    }
                });
    }

}