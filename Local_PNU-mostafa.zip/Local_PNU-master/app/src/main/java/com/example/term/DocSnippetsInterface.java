package com.example.term;

import java.util.List;

/**
 * Interface for {@link DocSnippets}.
 */
public interface DocSnippetsInterface {
    void addShop(String Kinds, String Shop_name, String Time, List Menu_name, List Menu_price, double latitude, double longitude);

    void getShop(String Kinds, String Shop_name, double latitude, double longitude);

    void getCategory(String Kinds, double latitude, double longitude);
}