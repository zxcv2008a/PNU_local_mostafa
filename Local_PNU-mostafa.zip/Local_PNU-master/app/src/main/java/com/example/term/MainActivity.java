package com.example.term;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;

public class MainActivity extends AppCompatActivity {
    public ImageButton coffe_btn;
    public ImageButton resturant_btn;
    public Button setting_btn;
    public Button language_btn;
    public Button about_btn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        coffe_btn=(ImageButton)findViewById(R.id.coffebtn);
        resturant_btn=(ImageButton)findViewById(R.id.resturantbtn);
        setting_btn=(Button)findViewById(R.id.settingsbtn);
        language_btn=(Button)findViewById(R.id.languagebtn);
        about_btn=(Button)findViewById(R.id.aboutbtn);
        coffe_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent1 = new Intent(MainActivity.this, DocSnippets.class);
                intent1.putExtra("Function", "Category");
                intent1.putExtra("Category","Foods");
                intent1.putExtra("Latitude", 35.231331);
                intent1.putExtra("Longitude", 129.084917);
                startActivityForResult(intent1, 0);
            }
        });
        resturant_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, resturant_sub.class);
                startActivity(intent);
            }
        });
        setting_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, setting_sub.class);
                startActivity(intent);
            }
        });
        language_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, language_sub.class);
                startActivity(intent);
            }
        });
        about_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, about_sub.class);
                startActivity(intent);
            }

        });
    }
}